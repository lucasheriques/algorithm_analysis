#!/bin/bash
pypy diameter_python2.py -i $1 -o $2